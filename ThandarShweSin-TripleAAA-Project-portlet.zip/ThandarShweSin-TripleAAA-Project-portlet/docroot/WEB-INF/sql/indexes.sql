create index IX_4261DEF7 on TDSS_Customer (groupId);
create index IX_1780C341 on TDSS_Customer (uuid_);
create index IX_5B0C5E47 on TDSS_Customer (uuid_, companyId);
create unique index IX_F2D5CA89 on TDSS_Customer (uuid_, groupId);

create index IX_6046FE77 on TDSS_Services (groupId);
create index IX_8327C2C1 on TDSS_Services (uuid_);
create index IX_1832AEC7 on TDSS_Services (uuid_, companyId);
create unique index IX_8E563B09 on TDSS_Services (uuid_, groupId);