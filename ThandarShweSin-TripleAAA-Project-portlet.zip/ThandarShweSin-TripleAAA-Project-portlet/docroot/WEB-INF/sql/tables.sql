create table TDSS_Customer (
	uuid_ VARCHAR(75) null,
	customerId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	customerName VARCHAR(75) null,
	customerEmail VARCHAR(75) null,
	customerContact VARCHAR(75) null,
	customerAddress VARCHAR(75) null,
	customerNRC VARCHAR(75) null,
	customerPayment VARCHAR(75) null,
	servicesId LONG
);

create table TDSS_Services (
	uuid_ VARCHAR(75) null,
	servicesId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	servicesName VARCHAR(75) null,
	servicesPrice VARCHAR(75) null,
	servicesDesc VARCHAR(75) null
);