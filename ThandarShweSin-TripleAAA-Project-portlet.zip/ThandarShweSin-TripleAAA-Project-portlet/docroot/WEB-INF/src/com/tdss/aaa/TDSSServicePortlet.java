package com.tdss.aaa;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.tdss.aaa.model.Services;
import com.tdss.aaa.service.ServicesLocalServiceUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;


public class TDSSServicePortlet extends MVCPortlet {

	public void addService(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, SystemException {

		ServiceContext serviceContext = ServiceContextFactory.getInstance(Services.class.getName(), actionRequest);

		String servicesName = ParamUtil.getString(actionRequest, "servicesName");
		String servicesPrice = ParamUtil.getString(actionRequest, "servicesPrice");
		String servicesDesc = ParamUtil.getString(actionRequest, "servicesDesc");
		//PizzaId which want to edit (from pizza.jsp)
		Long servicesId = ParamUtil.getLong(actionRequest, "servicesId");
		if(servicesId > 0){
			try {
				ServicesLocalServiceUtil.updateServices(serviceContext.getUserId(), servicesId, servicesName, servicesPrice, servicesDesc, serviceContext);
				System.out.println(servicesId + " " + " is updated successfully");
			} catch (Exception e) {
				e.printStackTrace();
				actionResponse.setRenderParameter("mvcPath", "/html/tdssservice/service.jsp");
			}
		}
		else{
		try {
			ServicesLocalServiceUtil.addServices(serviceContext.getUserId(), servicesName, servicesPrice, servicesDesc, serviceContext);
			System.out.println("Service is added successfully");
		} catch (Exception e) {
			e.printStackTrace();
			actionResponse.setRenderParameter("mvcPath", "/html/tdssservice/service.jsp");
			}
		}
	}


	public void deleteServices(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, SystemException {
		long servicesId = ParamUtil.getLong(actionRequest, "servicesId");
		
		try {
			ServicesLocalServiceUtil.deleteServices(servicesId);
			System.out.println(servicesId + "" + "is deleted");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}