
package com.tdss.aaa.service.impl;

import java.util.Date;
import java.util.List;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.tdss.aaa.ServicesNameException;
import com.tdss.aaa.ServicesPriceException;
import com.tdss.aaa.model.Services;
import com.tdss.aaa.service.base.ServicesLocalServiceBaseImpl;


public class ServicesLocalServiceImpl extends ServicesLocalServiceBaseImpl {
	//Finder Method 
	public List<Services> getServicexs(long groupId) throws SystemException{
		return servicesPersistence.findByServicesFinder(groupId);
	}
	
	//Finder Method with pagination
	public List<Services> getServicexs(long groupId, int start, int end) throws SystemException{
		return servicesPersistence.findByServicesFinder(groupId, start, end);
	}
	
	//Validation method
	protected void validate(String serviceName, String servicesPrice) throws PortalException{
		if(Validator.isNull(serviceName))
			throw new ServicesNameException();
		
		if(Validator.isNull(servicesPrice))
			throw new ServicesPriceException();
	}
	
	//Add Pizza Method
	public Services addServices(long userId, String servicesName, String servicesPrice, String servicesDesc, ServiceContext serviceContext) throws PortalException, SystemException{
		
		//Scope Column(uuid, groupId, companyId)
		//User Column (userId, userName)
		//Audit Column (createDate, modifiedDate)
		
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		long servicesId = counterLocalService.increment();
		
		Services services = servicesPersistence.create(servicesId);
		
		services.setUuid(serviceContext.getUuid());
		services.setGroupId(serviceContext.getScopeGroupId());
		services.setCompanyId(serviceContext.getCompanyId());
		
		services.setUserId(user.getUserId());
		services.setUserName(user.getFullName());
		
		services.setCreateDate(serviceContext.getCreateDate(now));
		services.setModifiedDate(serviceContext.getModifiedDate(now));
		
		services.setServicesName(servicesName);
		services.setServicesPrice(servicesPrice);
		services.setServicesDesc(servicesDesc);
		
		services.setExpandoBridgeAttributes(serviceContext);
		
		servicesPersistence.update(services);
		resourceLocalService.addResources(user.getCompanyId(), serviceContext.getScopeGroupId(), userId, Services.class.getName(), servicesId, false, true, true);
		
		return services;
	}

	public Services updateServices(long userId, long servicesId, String servicesName, String servicesPrice, String servicesDesc, ServiceContext serviceContext) throws PortalException, SystemException {
		//get current pizzaId 
		Services services = servicesPersistence.findByPrimaryKey(servicesId);
		
		//set modified date
		services.setModifiedDate(serviceContext.getModifiedDate());
		
		//allows to edit or update pizzaName, pizzaPrice, pizzaIngredients
		services.setServicesName(servicesName);
		services.setServicesPrice(servicesPrice);
		services.setServicesDesc(servicesDesc);
		
		services.setExpandoBridgeAttributes(serviceContext);
		
		servicesPersistence.update(services);
		User user = userPersistence.findByPrimaryKey(userId);
		
		resourceLocalService.updateResources(
				user.getCompanyId(), serviceContext.getScopeGroupId(), Services.class.getName(), servicesId,
				serviceContext.getGroupPermissions(),
				serviceContext.getGuestPermissions());
		return services;
	}


	public Services deleteServices(long userId, long servicesId, ServiceContext serviceContext)
			throws PortalException, SystemException {
		//Get pizzaId which we want to delete
		Services services = getServices(servicesId);
		//Call deletePizza method by passing current pizzaId which want to delete
		services =  deleteServices(servicesId);
		//return current SERVICES object
		resourceLocalService.deleteResource(
				serviceContext.getCompanyId(), Services.class.getName(),
				ResourceConstants.SCOPE_INDIVIDUAL, servicesId);
	
		return services;
	}

	@Override
	public List<Services> getServiceses(long groupId) throws SystemException {
		return servicesPersistence.findByServicesFinder(groupId);
	}

	@Override
	public List<Services> getServices(long groupId, int start, int end) throws SystemException {
		// TODO Auto-generated method stub
		return null;
	}
	
}