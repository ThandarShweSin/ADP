package com.tdss.aaa;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.tdss.aaa.model.Customer;
import com.tdss.aaa.service.CustomerLocalServiceUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;


public class TDSSCustomerPortlet extends MVCPortlet {

	public void addCustomer(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, SystemException {

		ServiceContext serviceContext = ServiceContextFactory.getInstance(Customer.class.getName(), actionRequest);

		String customerName = ParamUtil.getString(actionRequest, "customerName");
		String customerEmail = ParamUtil.getString(actionRequest, "customerEmail");
		String customerContact = ParamUtil.getString(actionRequest, "customerContact");
		String customerAddress = ParamUtil.getString(actionRequest, "customerAddress");
		String customerNric = ParamUtil.getString(actionRequest, "customerNric");
		String customerPayment = ParamUtil.getString(actionRequest, "customerPayment");
		Long servicesId = ParamUtil.getLong(actionRequest, "servicesId");
		Long customerId = ParamUtil.getLong(actionRequest, "customerId");
		
		if(customerId>0){
			try {
				CustomerLocalServiceUtil.updateCustomer(serviceContext.getUserId(), customerId, customerName, customerEmail, customerContact, customerAddress, customerNric, customerPayment, servicesId, serviceContext);
				System.out.println(customerId + " " + " is updated successfully");
			} catch (Exception e) {
				e.printStackTrace();
				actionResponse.setRenderParameter("mvcPath", "/html/tdsscustomer/customer.jsp");
			}
		}
		else{
			try {
				CustomerLocalServiceUtil.addCustomer(serviceContext.getUserId(), customerName, customerEmail, customerContact, customerAddress, customerNric, customerPayment, servicesId, serviceContext);
				System.out.println("Customer is added to the database");
			} catch (Exception e) {
				e.printStackTrace();
				actionResponse.setRenderParameter("mvcPath", "/html/tdsscustomer/customer.jsp");
			}
		}
	}
	
	public void deleteCustomer(ActionRequest actionRequest, ActionResponse actionResponse) {
		long customerId = ParamUtil.getLong(actionRequest, "customerId");
		
		try {
			CustomerLocalServiceUtil.deleteCustomer(customerId);
			System.out.println(customerId + " " + " is deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}