package com.tdss.aaa.util;

public class WebKeys implements com.liferay.portal.kernel.util.WebKeys{
	public static final String CUSTOMER = "CUSTOMER";
	public static final String SERVICES = "SERVICES";

}

